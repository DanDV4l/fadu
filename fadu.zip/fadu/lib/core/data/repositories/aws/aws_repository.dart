import 'package:fadu/domain/repositories/repository.dart';

class AwsRepository implements Repository {
  @override
  Stream fetch({required userName}) {
    dynamic a = userName;
    return a;
  }

  @override
  send({required message}) {}
}
