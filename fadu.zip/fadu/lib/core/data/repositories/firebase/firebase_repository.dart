import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fadu/core/data/usecases/firebase/firebase_fetchmessages_usecase.dart';
import 'package:fadu/core/data/usecases/firebase/firebase_sendmessage_usecase.dart';
import 'package:fadu/domain/repositories/repository.dart';

class FirebaseRepository implements Repository {
  FirebaseFetchMessagesUsecase firebaseFetch = FirebaseFetchMessagesUsecase();
  FirebaseSendMessageUsecase firebaseSend = FirebaseSendMessageUsecase();
  @override
  Stream<DocumentSnapshot> fetch({required userName}) {
    return firebaseFetch(userName: userName);
  }

  @override
  send({required message}) {
    return firebaseSend(message: message);
  }
}
