import 'package:fadu/core/data/external/firebase/usecases/firebase_messages_usecase.dart';
import 'package:fadu/domain/entities/message_entity.dart';
import 'package:fadu/domain/repositories/messages_repository.dart';
import 'package:fadu/domain/usecases/message_usecase.dart';

class FirebaseRepository implements MessagesRepository {
  MessageUsecase messages = FirebaseMessagesUsecase();
  @override
  Stream fetch({required userName}) {
    return messages.fetch(userName: userName);
  }

  @override
  send({required MessageEntity message}) {
    messages.send(message: message);
  }
}
