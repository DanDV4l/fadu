import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fadu/domain/usecases/fetch_messages/fetch_messages_usecase.dart';

class FirebaseFetchMessagesUsecase implements FetchMessagesUsecase {
  var firestore = FirebaseFirestore.instance.collection('Messages');
  @override
  Stream<DocumentSnapshot> call({required userName}) {
    return firestore.doc(userName).snapshots();
  }
}
