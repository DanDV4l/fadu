import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fadu/domain/entities/message_entity.dart';
import 'package:fadu/domain/usecases/send_message/send_message_usecase.dart';

class FirebaseSendMessageUsecase implements SendMessageUsecase {
  @override
  call({required MessageEntity message}) async {
    var firestore = FirebaseFirestore.instance.collection('Messages');

    await firestore.doc(message.messageAuthor.userID).set({
      "${message.messageDestination.userID}": [
        {
          "messageAuthor": message.messageAuthor.userID,
          "messageDestination": message.messageDestination.userID,
          "messageContent": message.messageContent,
          "messageDateTime": message.messageDateTime
        }
      ]
    });
  }
}

// add({
//       "messageAuthor": message.messageAuthor.userID,
//       "messageDestination": message.messageDestination,
//       "messageContent": message.messageContent,
//       "messageDateTime": message.messageDateTime
//     });
//   }