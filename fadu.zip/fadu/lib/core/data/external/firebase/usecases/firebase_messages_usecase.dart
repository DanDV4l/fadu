import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fadu/core/data/dtos/message_dto.dart';
import 'package:fadu/domain/entities/message_entity.dart';
import 'package:fadu/domain/usecases/message_usecase.dart';

class FirebaseMessagesUsecase implements MessageUsecase {
  var firestore = FirebaseFirestore.instance.collection('profiles');

//FETCH MESSAGES
  @override
  Stream<QuerySnapshot> fetch({required userName}) async* {
    yield* firestore.doc(userName).collection('messages').snapshots();
  }

//SEND MESSAGE
  @override
  send({required MessageEntity message}) async {
    MessageDTO messageDto = MessageDTO();

    //Post - Author
    await firestore
        .doc(message.messageAuthor.userID)
        .collection('messages')
        .doc(message.messageDestination.userID)
        .set({
      message.messageDestination.userID: [messageDto.toMap(message: message)]
    });

    //Post - Destination
    await firestore
        .doc(message.messageDestination.userID)
        .collection('messages')
        .doc(message.messageAuthor.userID)
        .set({
      message.messageAuthor.userID: [messageDto.toMap(message: message)]
    });
  }
}
