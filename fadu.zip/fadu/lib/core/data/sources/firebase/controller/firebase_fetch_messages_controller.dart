import 'package:cloud_firestore/cloud_firestore.dart';

class FirebaseFetchMessagesController {
  Stream<QuerySnapshot> call({required userName}) async* {
    yield* FirebaseFirestore.instance
        .collection('profiles')
        .doc(userName)
        .collection('messages')
        .snapshots();
  }
}
