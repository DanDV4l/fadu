import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fadu/core/data/dtos/message_dto.dart';
import 'package:fadu/domain/entities/message_entity.dart';

class FirebaseSendMessageController {
  var firestore = FirebaseFirestore.instance.collection('profiles');

  call({required MessageEntity message}) async {
    MessageDTO messageDto = MessageDTO();

    try {
      await firestore
          .doc(message.messageAuthor.userID)
          .collection('messages')
          .doc(message.messageDestination.userID)
          .get()
          .then((value) async {
        List messages = [];
        messages = value.data()!['messages'];
        messages.add(messageDto.toMap(message: message));

        await firestore
            .doc(message.messageAuthor.userID)
            .collection('messages')
            .doc(message.messageDestination.userID)
            .set({'messages': messages});

        await firestore
            .doc(message.messageDestination.userID)
            .collection('messages')
            .doc(message.messageAuthor.userID)
            .set({'messages': messages});
      });
    } catch (e) {
      await firestore
          .doc(message.messageAuthor.userID)
          .collection('messages')
          .doc(message.messageDestination.userID)
          .set({
        'messages': [messageDto.toMap(message: message)]
      });

      await firestore
          .doc(message.messageDestination.userID)
          .collection('messages')
          .doc(message.messageAuthor.userID)
          .set({
        'messages': [messageDto.toMap(message: message)]
      });
    }
  }
}
