import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class FirebaseDataController {
  call({required snapshotData}) async {
    List receivedData = [];
    snapshotData.forEach!((AsyncSnapshot<QuerySnapshot<Object?>> element) {
      receivedData.add(element.data!.docs);
    });
    return receivedData;
  }
}
