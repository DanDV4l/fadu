import 'package:fadu/domain/entities/message_entity.dart';
import 'package:fadu/domain/entities/user_entity.dart';

class MockData {
  static final UserEntity _user1 = UserEntity(
      userID: 'user1ID', userName: 'user 1', userContact: 'user 1 contact');
  static final UserEntity _user2 = UserEntity(
      userID: 'user2ID', userName: 'user 2 ', userContact: 'user 2 contact');
  MessageEntity message = MessageEntity(
      messageAuthor: _user1,
      messageDestination: _user2,
      messageContent: 'messageContent',
      messageDateTime: 'userContent');
}
