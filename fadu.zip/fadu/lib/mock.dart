import 'package:fadu/domain/entities/message_entity.dart';
import 'package:fadu/domain/entities/user_entity.dart';

class MockData {
  static UserEntity user1 = UserEntity(
      userID: 'user1ID', userName: 'user 1', userContact: 'user 1 contact');
  static UserEntity user4 = UserEntity(
      userID: 'user4ID', userName: 'user 4 ', userContact: 'user 4 contact');
  MessageEntity message = MessageEntity(
      messageAuthor: user1,
      messageDestination: user4,
      messageContent: 'messageContent',
      messageDateTime: 'userContent');
}
