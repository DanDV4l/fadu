import 'package:fadu/domain/entities/message_entity.dart';
import 'package:fadu/domain/repositories/repository.dart';
import 'package:fadu/domain/usecases/send_message/send_message_usecase.dart';

class SendMessageUsecaseImp implements SendMessageUsecase {
  Repository repository = Repository();
  @override
  call({required MessageEntity message}) async {
    await repository.send(message: message);
  }
}
