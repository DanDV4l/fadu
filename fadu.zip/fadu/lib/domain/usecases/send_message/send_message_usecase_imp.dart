import 'package:fadu/domain/repositories/repository.dart';
import 'package:fadu/domain/usecases/send_message/send_message_usecase.dart';

class SendMessageUsecaseImp implements SendMessageUsecase {
  Repository repository = Repository();
  @override
  call() {
    repository.send();
  }
}
