import 'package:fadu/domain/entities/message_entity.dart';
import 'package:fadu/domain/usecases/send_message/send_message_usecase_imp.dart';

class SendMessageUsecase {
  call({required MessageEntity message}) {
    SendMessageUsecase sendMessage = SendMessageUsecaseImp();
    sendMessage(message: message);
  }
}
