import 'package:fadu/domain/usecases/send_message/send_message_usecase_imp.dart';

class SendMessageUsecase {
  call() {
    SendMessageUsecase sendMessage = SendMessageUsecaseImp();
    sendMessage();
  }
}
