import 'package:fadu/domain/repositories/repository.dart';
import 'package:fadu/domain/usecases/fetch_messages/fetch_messages_usecase.dart';

class FetchMessagesUsecaseImp implements FetchMessagesUsecase {
  Repository repository = Repository();
  @override
  call({required userName}) {
    return repository.fetch(userName: userName);
  }
}
