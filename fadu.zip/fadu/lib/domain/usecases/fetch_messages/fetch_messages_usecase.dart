import 'package:fadu/domain/usecases/fetch_messages/fetch_messages_usecase_imp.dart';

class FetchMessagesUsecase {
  call({required userName}) {
    FetchMessagesUsecaseImp fetchMessages = FetchMessagesUsecaseImp();
    return fetchMessages(userName: userName);
  }
}
