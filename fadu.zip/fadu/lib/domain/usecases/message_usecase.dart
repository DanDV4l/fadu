import 'package:fadu/core/data/repositories/firebase_repository.dart';
import 'package:fadu/domain/entities/message_entity.dart';
import 'package:fadu/domain/repositories/messages_repository.dart';

MessagesRepository repository = FirebaseRepository();

class MessageUsecase {
  fetch({required userName}) async* {
    yield* repository.fetch(userName: userName);
  }

  send({required MessageEntity message}) {
    repository.send(message: message);
  }
}
