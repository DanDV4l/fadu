import 'package:fadu/domain/entities/message_entity.dart';

abstract class MessagesUsecase {
  fetch({required userName}) async* {}

  send({required MessageEntity message}) {}
}
