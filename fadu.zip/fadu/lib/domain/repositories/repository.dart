import 'package:fadu/core/data/repositories/firebase/firebase_repository.dart';

Repository setRepository = FirebaseRepository();

class Repository {
  Stream fetch({required userName}) {
    return setRepository.fetch(userName: userName);
  }

  send({required message}) async {
    await setRepository.send(message: message);
  }
}
