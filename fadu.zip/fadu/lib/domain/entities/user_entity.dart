class UserEntity {
  String userID;
  String userName;
  String userContact;

  UserEntity(
      {required this.userID,
      required this.userName,
      required this.userContact});
}
