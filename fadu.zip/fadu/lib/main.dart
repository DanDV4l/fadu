import 'package:fadu/core/ui/appwidgets/firebase_appwidget.dart';
import 'package:flutter/material.dart';

void main() => runApp(const FirebaseAppWidget());
