import 'package:fadu/core/data/repositories/firebase/firebase_options.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

Future initialize =
    Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

void main() {
  WidgetsFlutterBinding.ensureInitialized();
}
