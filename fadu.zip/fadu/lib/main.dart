import 'package:fadu/core/data/repositories/firebase/firebase_options.dart';
import 'package:fadu/domain/usecases/send_message/send_message_usecase.dart';
import 'package:fadu/mock.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

Future initialize =
    Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MaterialApp(home: Home()));
}

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: initialize,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.done) {
          MockData mock = MockData();
          SendMessageUsecase send = SendMessageUsecase();

          return TextButton(
            child: const Text('Test'),
            onPressed: () {
              send(message: mock.message);
            },
          );
        }
        return const SizedBox();
      },
    );
  }
}
