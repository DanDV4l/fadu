package gd.rf.wwitdev.fadu

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
